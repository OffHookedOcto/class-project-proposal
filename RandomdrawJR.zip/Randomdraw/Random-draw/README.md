# Turtle-Draw
# By Juan Rodriguez
# crdeit Eric Pogue 
# project inspired by Rachel Littlejohn Final Project 12/16/22